function getDateString(date) {
	var month = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	return ("0"+date.getDate()).slice(-2)
			+"-"+
			month[date.getMonth()]
			+"-"+
			date.getFullYear();
}

function readUrl(){
	var url = window.location.href;
	retrun url;
}

function Redirect() {
    window.location="http://developerowl.com";
}

function homePage() {
	alert("hello");
}

homePage();